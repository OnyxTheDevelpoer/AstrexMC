/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.astrexmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.Item;

import net.mcreator.astrexmod.item.AstrexItem;
import net.mcreator.astrexmod.AstrexModMod;

import java.util.function.Function;

public class AstrexModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(AstrexModMod.MODID);
	public static final DeferredItem<Item> ASTREX;
	static {
		ASTREX = register("astrex", AstrexItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}
}