/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.astrexmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.astrexmod.block.AstrexPortalBlock;
import net.mcreator.astrexmod.AstrexModMod;

import java.util.function.Function;

public class AstrexModModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(AstrexModMod.MODID);
	public static final DeferredBlock<Block> ASTREX_PORTAL;
	static {
		ASTREX_PORTAL = register("astrex_portal", AstrexPortalBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}