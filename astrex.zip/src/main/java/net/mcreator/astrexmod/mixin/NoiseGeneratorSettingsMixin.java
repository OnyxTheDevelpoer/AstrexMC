package net.mcreator.astrexmod.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.astrexmod.init.AstrexModModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements AstrexModModBiomes.AstrexModModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> astrex_mod_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.astrex_mod_dimensionTypeReference != null) {
			retval = AstrexModModBiomes.adaptSurfaceRule(retval, this.astrex_mod_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setastrex_modDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.astrex_mod_dimensionTypeReference = dimensionType;
	}
}